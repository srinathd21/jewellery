<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('Asia/Kolkata');

/* -------------------------------------------------------
   DATABASE CONFIG
------------------------------------------------------- */
$DB_HOST = 'localhost';
$DB_NAME = 'u966043993_vannamayil';
$DB_USER = 'u966043993_vannamayil';
$DB_PASS = 'Vannamayil@29';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    die('Database connection failed: ' . $e->getMessage());
}

/* -------------------------------------------------------
   COMMON HELPERS
------------------------------------------------------- */
if (!function_exists('h')) {
    function h($value): string
    {
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('tableExists')) {
    function tableExists(mysqli $conn, string $tableName): bool
    {
        $safe = $conn->real_escape_string($tableName);
        $sql = "SHOW TABLES LIKE '{$safe}'";
        $res = $conn->query($sql);
        return $res && $res->num_rows > 0;
    }
}

if (!function_exists('getRoleName')) {
    function getRoleName(mysqli $conn, int $userId): string
    {
        $sql = "SELECT r.role_name
                FROM users u
                INNER JOIN roles r ON r.id = u.role_id
                WHERE u.id = ?
                LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res ? $res->fetch_assoc() : null;
        $stmt->close();

        return (string)($row['role_name'] ?? '');
    }
}

if (!function_exists('isLoggedIn')) {
    function isLoggedIn(): bool
    {
        return isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] > 0;
    }
}

if (!function_exists('requireLogin')) {
    function requireLogin(string $redirect = 'login.php'): void
    {
        if (!isLoggedIn()) {
            header('Location: ' . $redirect);
            exit;
        }
    }
}

if (!function_exists('isSuperAdmin')) {
    function isSuperAdmin(): bool
    {
        return isset($_SESSION['role_name']) && $_SESSION['role_name'] === 'Super Admin';
    }
}

if (!function_exists('requireSuperAdmin')) {
    function requireSuperAdmin(string $redirect = 'login.php'): void
    {
        requireLogin($redirect);

        if (!isSuperAdmin()) {
            die('Access denied. Super Admin only.');
        }
    }
}

if (!function_exists('currentUserId')) {
    function currentUserId(): int
    {
        return (int)($_SESSION['user_id'] ?? 0);
    }
}

if (!function_exists('currentBusinessId')) {
    function currentBusinessId(): ?int
    {
        return isset($_SESSION['business_id']) && $_SESSION['business_id'] !== ''
            ? (int)$_SESSION['business_id']
            : null;
    }
}

if (!function_exists('currentRoleName')) {
    function currentRoleName(): string
    {
        return (string)($_SESSION['role_name'] ?? '');
    }
}

if (!function_exists('refreshSessionUser')) {
    function refreshSessionUser(mysqli $conn, int $userId): void
    {
        $sql = "SELECT 
                    u.id,
                    u.business_id,
                    u.full_name,
                    u.username,
                    u.email,
                    r.role_name,
                    b.business_name
                FROM users u
                INNER JOIN roles r ON r.id = u.role_id
                LEFT JOIN businesses b ON b.id = u.business_id
                WHERE u.id = ?
                LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res ? $res->fetch_assoc() : null;
        $stmt->close();

        if ($row) {
            $_SESSION['user_id']       = (int)$row['id'];
            $_SESSION['business_id']   = isset($row['business_id']) ? (int)$row['business_id'] : null;
            $_SESSION['full_name']     = (string)($row['full_name'] ?? '');
            $_SESSION['username']      = (string)($row['username'] ?? '');
            $_SESSION['email']         = (string)($row['email'] ?? '');
            $_SESSION['role_name']     = (string)($row['role_name'] ?? '');
            $_SESSION['business_name'] = (string)($row['business_name'] ?? '');
        }
    }
}

if (!function_exists('addAuditLog')) {
    function addAuditLog(
        mysqli $conn,
        ?int $businessId,
        ?int $userId,
        string $moduleName,
        string $actionType,
        ?int $referenceId = null,
        string $description = ''
    ): void {
        if (!tableExists($conn, 'audit_logs')) {
            return;
        }

        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        $sql = "INSERT INTO audit_logs
                (business_id, user_id, module_name, action_type, reference_id, description, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            'iississs',
            $businessId,
            $userId,
            $moduleName,
            $actionType,
            $referenceId,
            $description,
            $ipAddress,
            $userAgent
        );
        $stmt->execute();
        $stmt->close();
    }
}
?>
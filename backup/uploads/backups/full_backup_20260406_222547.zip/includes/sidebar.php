<div id="sidebar-menu">
    <ul class="metismenu list-unstyled" id="side-menu">

        <li class="menu-title">Business Panel</li>

        <li>
            <a href="index.php" class="waves-effect">
                <i class="dripicons-device-desktop"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-cart"></i>
                <span>Billing</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="billing.php">Create Bill</a></li>
                <li><a href="sales.php">Sales Bills</a></li>
                <li><a href="sales-return.php">Sales Return</a></li>
                <li><a href="estimate.php">Estimate / Quotation</a></li>
                <li><a href="print-bill.php">Print Bill</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-archive"></i>
                <span>Products</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="categories.php">Categories</a></li>
                <li><a href="products.php">All Products</a></li>
                <li><a href="product-add.php">Add Product</a></li>
                <li><a href="product-stock.php">Product Stock</a></li>
                <li><a href="barcode-print.php">Barcode Print</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-to-do"></i>
                <span>Stock</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="stock-overview.php">Stock Overview</a></li>
                <li><a href="stock-movements.php">Stock Movements</a></li>
                <li><a href="low-stock-report.php">Low Stock Report</a></li>
                <li><a href="stock-adjustment.php">Stock Adjustment</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-box"></i>
                <span>Purchases</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="purchase-add.php">Add Purchase</a></li>
                <li><a href="purchases.php">Purchase List</a></li>
                <li><a href="purchase-return.php">Purchase Return</a></li>
                <li><a href="suppliers-payments.php">Supplier Payments</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-user-group"></i>
                <span>Customers</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="customers.php">All Customers</a></li>
                <li><a href="customer-add.php">Add Customer</a></li>
                <li><a href="customer-payments.php">Customer Payments</a></li>
                <li><a href="customer-ledger.php">Customer Ledger</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-store"></i>
                <span>Suppliers</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="suppliers.php">All Suppliers</a></li>
                <li><a href="supplier-add.php">Add Supplier</a></li>
                <li><a href="supplier-ledger.php">Supplier Ledger</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-wallet"></i>
                <span>Accounts</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="expenses.php">Expenses</a></li>
                <li><a href="collections.php">Collections</a></li>
                <li><a href="daybook.php">Day Book</a></li>
                <li><a href="cashbook.php">Cash Book</a></li>
                <li><a href="payment-methods.php">Payment Methods</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-graph-line"></i>
                <span>Reports</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="sales-report.php">Sales Report</a></li>
                <li><a href="purchase-report.php">Purchase Report</a></li>
                <li><a href="stock-report.php">Stock Report</a></li>
                <li><a href="profit-loss.php">Profit & Loss</a></li>
                <li><a href="expense-report.php">Expense Report</a></li>
                <li><a href="gst-report.php">GST Report</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-user"></i>
                <span>Users</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="users.php">All Users</a></li>
                <li><a href="user-add.php">Add User</a></li>
                <li><a href="roles.php">Roles & Permissions</a></li>
            </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="dripicons-gear"></i>
                <span>Settings</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="company-settings.php">Company Settings</a></li>
                <li><a href="invoice-settings.php">Invoice Settings</a></li>
                <li><a href="silver-rate-settings.php">Silver Rate Settings</a></li>
                <li><a href="backup.php">Backup</a></li>
                <li><a href="profile.php">Profile</a></li>
            </ul>
        </li>

        <li>
            <a href="logout.php" class="waves-effect">
                <i class="dripicons-exit"></i>
                <span>Logout</span>
            </a>
        </li>

    </ul>
</div>